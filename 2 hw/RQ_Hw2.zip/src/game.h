#pragma once
#include "physicsgen.h"


class Game
{
public:
    PhysGen phys;
    const double kTimeStep = 0.1;
};