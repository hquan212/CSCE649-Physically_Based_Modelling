#include "ball.h"


Ball::Ball() : x(0), y(0), z(0), vx(0), vy(0), vz(0), color(0), isalive(true), collided(false), time(0)
{
    //Create the ball objects with all 0
}